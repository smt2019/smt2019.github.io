This directory contains the informal SMT 2019 proceedings, and was
prepared with the help of EasyChair.

See contents.html for a table of contents with links to papers.
